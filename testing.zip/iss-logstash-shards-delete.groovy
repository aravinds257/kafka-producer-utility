import java.time.*;

LocalDate currentDate = LocalDate.now()
def deleteBeforeDate = currentDate.minusMonths(4)

if(currentDate.getYear().compareTo(deleteBeforeDate.getYear()) > 0){
    def proc1 =  "curl -XDELETE CX3PW3346:9200/logstash-test-instrumentation-iss-" + deleteBeforeDate.getYear() + ".*"
    def proc2 =  "curl -XDELETE ssc7p4841373.ad.imsi.com:9200/logstash-test-instrumentation-iss-" + deleteBeforeDate.getYear() + ".*"
    def proc3 = "curl -XDELETE ssc7p4841373.ad.imsi.com:9200/logstash-iss-" + deleteBeforeDate.getYear() + ".*"
    def proc4 = "curl -XDELETE CX3PW3346.ad.imsi.com:9200/logstash-iss-" + deleteBeforeDate.getYear() + ".*"
    this.&executeCommand(proc1)
    this.&executeCommand(proc2)
    this.&executeCommand(proc3)
    this.&executeCommand(proc4)

    this.&deleteShardsMonthWise(deleteBeforeDate)
}else{
    this.&deleteShardsMonthWise(deleteBeforeDate)
}

def deleteShardsMonthWise(LocalDate deleteBeforeDate){
    LocalDate startDate = new LocalDate(deleteBeforeDate.getYear(), Month.JANUARY.getValue(), 1)
    for(LocalDate date = startDate; startDate.isBefore(deleteBeforeDate) ; startDate = startDate.plusMonths(1)){
        println( startDate.toString() + " " + deleteBeforeDate.toString())
        def proc5 =  "curl -XDELETE CX3PW3346:9200/logstash-test-instrumentation-iss-" + deleteBeforeDate.getYear() + "." + date.getMonth().getValue() + ".*"
        def proc6 =  "curl -XDELETE ssc7p4841373.ad.imsi.com:9200/logstash-test-instrumentation-iss-" + deleteBeforeDate.getYear() + "." + date.getMonth().getValue() + ".*"
        def proc7 = "curl -XDELETE ssc7p4841373.ad.imsi.com:9200/logstash-iss-" + deleteBeforeDate.getYear() + "." + date.getMonth().getValue() + ".*"
        def proc8 = "curl -XDELETE CX3PW3346.ad.imsi.com:9200/logstash-iss-" + deleteBeforeDate.getYear() + "." + date.getMonth().getValue() + ".*"
        this.&executeCommand(proc5)
        this.&executeCommand(proc6)
        this.&executeCommand(proc7)
        this.&executeCommand(proc8)
    }
}

def executeCommand(String command){
    def commandAck = command.execute()
    def outStr = new StringBuffer()
    println(commandAck.waitForProcessOutput(outStr, System.err).toString())
}

