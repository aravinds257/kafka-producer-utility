package data.message;

public enum EntityType {
    ENTITY;
}
