package swing;

import net.miginfocom.swing.MigLayout;

import javax.swing.*;
import java.awt.*;

public class KafkaUtilityFrame extends JFrame {


    public KafkaUtilityFrame() {
        super("Kafka Utility");
        initializeUI();
    }

    private void initializeUI() {
        initializeWindowListener();
        layoutComponents();
    }

    private void initializeWindowListener() {
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    private void layoutComponents() {
        setMinimumSize(new Dimension(1000, 800));

        JPanel mainPanel = new JPanel(new MigLayout("fill"));

        mainPanel.add(new KafkaUtilityPanel(), "grow");
//
        add(mainPanel);
        pack();
        setVisible(true);
    }

}
