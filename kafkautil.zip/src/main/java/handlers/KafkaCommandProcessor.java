package handlers;

import data.message.EntityType;
import data.message.TopicName;
import data.message.TatInvestorRequest;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class KafkaCommandProcessor {

    private  final Logger logger = LoggerFactory.getLogger(KafkaCommandProcessor.class);

    private Map<TopicName, Object> investorRequests = new HashMap<>(8);

    public KafkaCommandProcessor() {

        populateJmsMessages();
    }

    private void populateJmsMessages() {
        long fundId = 1l;
        String firstName = "Investor One";
        String lastName = "Last Name";
        EntityType entityType = EntityType.ENTITY;
        investorRequests.put(TopicName.INVESTOR_ONBOARDING, new TatInvestorRequest(fundId, firstName, lastName, null, entityType));
    }

    public String generateJmsMessage(TopicName topicName) {
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonObject = null;
        try {
            jsonObject = objectMapper.writeValueAsString(investorRequests.get(topicName));
        } catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            return jsonObject;
        }
    }


}
