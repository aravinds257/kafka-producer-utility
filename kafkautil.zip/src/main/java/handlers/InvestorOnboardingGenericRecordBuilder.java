package handlers;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import data.message.InvestorType;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericArray;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.generic.GenericRecordBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class InvestorOnboardingGenericRecordBuilder {

    private final Logger logger = LoggerFactory.getLogger(InvestorOnboardingGenericRecordBuilder.class);

    public GenericRecord buildInvestorOnboardingGenericRecord(Schema schema, JsonObject investorOnboardingJsonObject) {

        //build Generic Record
        GenericRecordBuilder investorOnboardingRecordBuilder = new GenericRecordBuilder(schema);

        String entityType = getInvestorDetailFromJson(investorOnboardingJsonObject, "entityType");

        Long fundId = investorOnboardingJsonObject.has("fundId") ? investorOnboardingJsonObject.get("fundId").getAsLong() : 0L;

        String firstname = getInvestorDetailFromJson(investorOnboardingJsonObject, "firstName");
        String lastname = getInvestorDetailFromJson(investorOnboardingJsonObject, "lastName");
        String middleInitial = getInvestorDetailFromJson(investorOnboardingJsonObject, "middleInitial");
        String dateOfBirth = getInvestorDetailFromJson(investorOnboardingJsonObject, "dateOfBirth");
        String countryOfBirth = getInvestorDetailFromJson(investorOnboardingJsonObject, "countryOfBirth");


        String residence = getInvestorDetailFromJson(investorOnboardingJsonObject, "residence");
        String citizen = getInvestorDetailFromJson(investorOnboardingJsonObject, "citizen");
        String principalPlaceOfBusiness = getInvestorDetailFromJson(investorOnboardingJsonObject, "principalPlaceOfBusiness");
        String jurisdictionOfOrganisation = getInvestorDetailFromJson(investorOnboardingJsonObject, "jurisdictionOfOrganisation");

        String taxEntityType = getInvestorDetailFromJson(investorOnboardingJsonObject, "taxEntityType");
        String organisationType = getInvestorDetailFromJson(investorOnboardingJsonObject, "organisationType");
        String investorType = getInvestorDetailFromJson(investorOnboardingJsonObject, "investorType");
        String taxHolderIdType = investorOnboardingJsonObject.has("identificationType") ? investorOnboardingJsonObject.get("identificationType").getAsString() : "Tax ID #";
        String taxHolderId = getInvestorDetailFromJson(investorOnboardingJsonObject, "identificationNumber");


        //Create the generic record
        investorOnboardingRecordBuilder.set("fundId", fundId);
        investorOnboardingRecordBuilder.set("firstName", firstname);
        investorOnboardingRecordBuilder.set("lastName", lastname);
        investorOnboardingRecordBuilder.set("middleInitial", middleInitial);
        investorOnboardingRecordBuilder.set("countryOfBirth", countryOfBirth);
        investorOnboardingRecordBuilder.set("dateOfBirth", dateOfBirth);
        investorOnboardingRecordBuilder.set("principalPlaceOfBusiness", principalPlaceOfBusiness);
        investorOnboardingRecordBuilder.set("residence", residence);
        investorOnboardingRecordBuilder.set("citizen", citizen);
        investorOnboardingRecordBuilder.set("jurisdictionOfOrganisation", jurisdictionOfOrganisation);
        GenericData.EnumSymbol entitySymbol = new GenericData.EnumSymbol(schema, InvestorType.typeOf(entityType));
        investorOnboardingRecordBuilder.set("entityType", entitySymbol);
        investorOnboardingRecordBuilder.set("taxEntityType", taxEntityType);
        investorOnboardingRecordBuilder.set("organisationType", organisationType);
        investorOnboardingRecordBuilder.set("investorType", investorType);
        investorOnboardingRecordBuilder.set("identificationType", taxHolderIdType);
        investorOnboardingRecordBuilder.set("identificationNumber", taxHolderId);
        logger.info("Investor details added in Generic Record");

        //adding Joint accounts if any
        List<GenericRecord> jointAccountsGenericRecordList = new ArrayList<>();
        if (investorOnboardingJsonObject.has("jointAccounts")) {
            Schema jointAccountsSchema  = schema.getField("jointAccounts").schema();
            GenericRecordBuilder jointAccountRecordBuilder = new GenericRecordBuilder(jointAccountsSchema.getElementType());
            for (JsonElement jsonAccount : investorOnboardingJsonObject.getAsJsonArray("jointAccounts")) {
                jointAccountsGenericRecordList.add(getJointAccountRecord(jointAccountRecordBuilder, jsonAccount.getAsJsonObject()));
            }
            GenericArray<GenericRecord> jointAccountsRecord = new GenericData.Array<>(jointAccountsSchema, jointAccountsGenericRecordList);
            investorOnboardingRecordBuilder.set("jointAccounts", jointAccountsRecord);
            logger.info("Joint Account details added in Generic Record");
        }

        if (investorOnboardingJsonObject.has("registeredContact")) {
            GenericRecordBuilder registeredContactBuilder = new GenericRecordBuilder(schema.getField("registeredContact").schema());
            GenericRecord registeredContactRecord = addingRegisteredAccount(registeredContactBuilder, investorOnboardingJsonObject.getAsJsonObject("registeredContact"));
            investorOnboardingRecordBuilder.set("registeredContact", registeredContactRecord);
            logger.info("Registered Contact details added in Generic Record");
        }
        return investorOnboardingRecordBuilder.build();
    }

    private String getInvestorDetailFromJson(JsonObject investorOnboardingJsonObject, String elementName) {
        return investorOnboardingJsonObject.has(elementName) ? investorOnboardingJsonObject.get(elementName).getAsString() : "";
    }

    private GenericRecord getJointAccountRecord(GenericRecordBuilder jointAccountsRecord, JsonObject jointAccountJsonObject) {

        String firstName = getInvestorDetailFromJson(jointAccountJsonObject, "firstName");
        String lastName = getInvestorDetailFromJson(jointAccountJsonObject, "lastName");
        String middleInitial = getInvestorDetailFromJson(jointAccountJsonObject, "middleInitial");
        String dateOfBirth = getInvestorDetailFromJson(jointAccountJsonObject, "dateOfBirth");
        String nationality = getInvestorDetailFromJson(jointAccountJsonObject, "nationality");
        String residence = getInvestorDetailFromJson(jointAccountJsonObject, "residence");
        String citizen = getInvestorDetailFromJson(jointAccountJsonObject, "citizen");
        String taxIdType = getInvestorDetailFromJson(jointAccountJsonObject, "identificationType");
        String taxHolderIdjoint = getInvestorDetailFromJson(jointAccountJsonObject, "identificationNumber");


        jointAccountsRecord.set("firstName", firstName);
        jointAccountsRecord.set("lastName", lastName);
        jointAccountsRecord.set("middleInitial", middleInitial);
        jointAccountsRecord.set("dateOfBirth", dateOfBirth);
        jointAccountsRecord.set("nationality", nationality);
        jointAccountsRecord.set("residence", residence);
        jointAccountsRecord.set("citizen", citizen);
        jointAccountsRecord.set("identificationType", taxIdType);
        jointAccountsRecord.set("identificationNumber", taxHolderIdjoint);

        return jointAccountsRecord.build();
    }

    private GenericRecord addingRegisteredAccount(GenericRecordBuilder registeredContact, JsonObject registeredContactJsonObject) {
        String title = getInvestorDetailFromJson(registeredContactJsonObject, "title");
        String name = getInvestorDetailFromJson(registeredContactJsonObject, "name");
        String suffix = getInvestorDetailFromJson(registeredContactJsonObject, "suffix");
        String firm = getInvestorDetailFromJson(registeredContactJsonObject, "firm");
        boolean isFaxFlagEnabled = registeredContactJsonObject.has("deliveryMethodFax") ? registeredContactJsonObject.get("deliveryMethodFax").getAsBoolean() : false;
        boolean isMailFlagEnabled = registeredContactJsonObject.has("deliveryMethodMail") ? registeredContactJsonObject.get("deliveryMethodMail").getAsBoolean() : false;
        boolean isEmailFlagEnabled = registeredContactJsonObject.has("deliveryMethodEmail") ? registeredContactJsonObject.get("deliveryMethodEmail").getAsBoolean() : false;
        boolean isTaxContact = registeredContactJsonObject.has("taxContact") ? registeredContactJsonObject.get("taxContact").getAsBoolean() : false;
        String email = getInvestorDetailFromJson(registeredContactJsonObject, "email");
        String workPhone = getInvestorDetailFromJson(registeredContactJsonObject, "workPhone");
        String workPhoneCountry = getInvestorDetailFromJson(registeredContactJsonObject, "workPhoneCountry");
        String homePhone = getInvestorDetailFromJson(registeredContactJsonObject, "homePhone");
        String homePhoneCountry = getInvestorDetailFromJson(registeredContactJsonObject, "homePhoneCountry");
        String cellPhone = getInvestorDetailFromJson(registeredContactJsonObject, "cellPhone");
        String cellPhoneCountry = getInvestorDetailFromJson(registeredContactJsonObject, "cellPhoneCountry");
        String faxNumber = getInvestorDetailFromJson(registeredContactJsonObject, "faxNumber");
        String faxCountry1 = getInvestorDetailFromJson(registeredContactJsonObject, "faxCountry1");
        String street1 = getInvestorDetailFromJson(registeredContactJsonObject, "street1");
        String street2 = getInvestorDetailFromJson(registeredContactJsonObject, "street2");
        String street3 = getInvestorDetailFromJson(registeredContactJsonObject, "street3");
        String city = getInvestorDetailFromJson(registeredContactJsonObject, "city");
        String state = getInvestorDetailFromJson(registeredContactJsonObject, "state");
        String country = getInvestorDetailFromJson(registeredContactJsonObject, "country");
        String zipcode = getInvestorDetailFromJson(registeredContactJsonObject, "zipcode");


        registeredContact.set("title", title);
        registeredContact.set("name", name);
        registeredContact.set("suffix", suffix);
        registeredContact.set("firm", firm);
        registeredContact.set("deliveryMethodFax", isFaxFlagEnabled);
        registeredContact.set("deliveryMethodMail", isMailFlagEnabled);
        registeredContact.set("deliveryMethodEmail", isEmailFlagEnabled);
        registeredContact.set("taxContact", isTaxContact);
        registeredContact.set("email", email);
        registeredContact.set("workPhone", workPhone);
        registeredContact.set("workPhoneCountry", workPhoneCountry);
        registeredContact.set("homePhone", homePhone);
        registeredContact.set("homePhoneCountry", homePhoneCountry);
        registeredContact.set("cellPhone", cellPhone);
        registeredContact.set("cellPhoneCountry", cellPhoneCountry);
        registeredContact.set("faxNumber", faxNumber);
        registeredContact.set("faxCountry1", faxCountry1);
        registeredContact.set("street1", street1);
        registeredContact.set("street2", street2);
        registeredContact.set("street3", street3);
        registeredContact.set("city", city);
        registeredContact.set("state", state);
        registeredContact.set("country", country);
        registeredContact.set("zipcode", zipcode);

        return registeredContact.build();
    }
}
