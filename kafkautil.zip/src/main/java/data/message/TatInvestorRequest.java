package data.message;

import java.util.Date;
import java.util.Objects;

public class TatInvestorRequest {
    private Long fundId;
    private String firstName;
    private String lastName;
    private Date dateOfBirth;
    private EntityType entityType;

    public TatInvestorRequest(Long fundId, String firstName, String lastName, Date dateOfBirth, EntityType entityType) {
        this.fundId = fundId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfBirth = dateOfBirth;
        this.entityType = entityType;
    }

    public TatInvestorRequest() {

    }

    public Long getFundId() {
        return fundId;
    }

    public EntityType getInvestorType() {
        return entityType;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public String getLastName() {
        return lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }

        TatInvestorRequest other = (TatInvestorRequest) obj;

        return Objects.equals(fundId, other.fundId)
                && Objects.equals(firstName, other.firstName)
                && Objects.equals(lastName, other.lastName)
                && Objects.equals(dateOfBirth, other.dateOfBirth)
                && Objects.equals(entityType, other.entityType);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }
}