package data.message;

public enum TopicName {

    INVESTOR_ONBOARDING("jab-ais-tat-investoronboarding-qa"),
    INVESTOR_SUCCESS("jab-ais-isz-investor"),
    INVESTOR_ERROR("jab-ais-isz-investor-error");

    private final String code;

    TopicName(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

}
