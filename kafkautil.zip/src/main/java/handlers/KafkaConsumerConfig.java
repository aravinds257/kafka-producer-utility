package handlers;

import data.message.Environment;
import data.message.TopicName;
import io.confluent.kafka.serializers.KafkaAvroDeserializer;
import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.time.Duration;
import java.util.Collections;
import java.util.Properties;

public class KafkaConsumerConfig {

    public String consume(Environment environment, TopicName topicName, boolean isAvroSelected) throws UnknownHostException {
        String BOOTSTRAP_SERVERS = environment.getBootStrapServers();
        String message = null;

        Properties consumerConfig = new Properties();
        consumerConfig.put("client.id", InetAddress.getLocalHost().getHostName());
        consumerConfig.put("bootstrap.servers", BOOTSTRAP_SERVERS);
        consumerConfig.put("group.id", "isz-investor-consumer-group-kafka-utility");
        consumerConfig.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        String serializer;
        if(!isAvroSelected){
            serializer = "org.apache.kafka.common.serialization.StringDeserializer";
        }else{
            serializer = "io.confluent.kafka.serializers.KafkaAvroDeserializer";
            consumerConfig.put("schema.registry.url", "http://localhost:8085");
        }
        consumerConfig.put("value.deserializer", serializer);
        consumerConfig.put("auto.offset.reset", "latest");
        consumerConfig.put("enable.auto.commit", "true");
        consumerConfig.put("max.poll.interval.ms", "2000000");
        consumerConfig.put("max.poll.records", "1");

        if (Environment.CLDDQA_CONSUMER == environment) {

            String trustStoreKeyStorePassword = "ssb123!";

            consumerConfig.put("security.protocol","SSL");
            consumerConfig.put("ssl.truststore.location", "\\\\inpnyc0011\\gldev\\Kafka\\kafka_producer_utility_beta\\keys\\aisdev-consumer.truststore.jks");
            consumerConfig.put("ssl.truststore.password", trustStoreKeyStorePassword);
            consumerConfig.put("ssl.keystore.location", "\\\\inpnyc0011\\gldev\\Kafka\\kafka_producer_utility_beta\\keys\\aisdev-consumer.keystore.jks");
            consumerConfig.put("ssl.keystore.password", trustStoreKeyStorePassword);
            consumerConfig.put("ssl.key.password",trustStoreKeyStorePassword);
            if (isAvroSelected){
                consumerConfig.put("schema.registry.url", "http://jabdlvc0108.it.statestr.com:8081");
            }
        }

        if(isAvroSelected){
            message = consumeAvroMessage(topicName, message, consumerConfig);
        }
        else{
            message = consumeJsonMessage(topicName, message, consumerConfig);
        }

        return message;
    }

    private String consumeAvroMessage(TopicName topicName, String message, Properties consumerConfig) {
        Consumer<String,GenericRecord> kafkaConsumer = new KafkaConsumer(consumerConfig);

        kafkaConsumer.subscribe(Collections.singletonList(topicName.getCode()));

        ConsumerRecords<String, GenericRecord> consumerRecords = kafkaConsumer.poll(Duration.ofSeconds(5));

        if (!consumerRecords.isEmpty()) {
            ConsumerRecord<String, GenericRecord> consumerRecord = consumerRecords.iterator().next();
            GenericRecord genericRecord = consumerRecord.value();
            message = genericRecord.toString();

        }

        kafkaConsumer.close();
        return message;
    }

    private String consumeJsonMessage(TopicName topicName, String message, Properties consumerConfig) {
        Consumer<String,String> kafkaConsumer = new KafkaConsumer(consumerConfig);

        kafkaConsumer.subscribe(Collections.singletonList(topicName.getCode()));

        ConsumerRecords<String, String> consumerRecords = kafkaConsumer.poll(Duration.ofSeconds(5));

        if (!consumerRecords.isEmpty()) {
            ConsumerRecord<String, String> consumerRecord = consumerRecords.iterator().next();
            String genericRecord = consumerRecord.value();
            message = genericRecord.toString();

        }

        kafkaConsumer.close();
        return message;
    }
}
