package swing;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import data.message.*;
import handlers.InvestorOnboardingGenericRecordBuilder;
import handlers.KafkaCommandProcessor;
import handlers.KafkaConsumerConfig;
import net.miginfocom.swing.MigLayout;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Properties;

public class KafkaUtilityPanel extends JPanel {

    private final Logger logger = LoggerFactory.getLogger(KafkaUtilityPanel.class);
    private static final Color DARK_GREEN = new Color(50, 124, 46);

    private JComboBox<Environment> environmentJComboBox;
    private JList<TopicName> topicNameJList;
    private JLabel statusLabel;
    private Label statusType;
    private JLabel kafkaConsumerProducerSelection;
    private JRadioButton kafkaProducer;
    private JRadioButton kafkaConsumer;
    private JCheckBox avroCheckbox;
    private ButtonGroup buttonGroup;
    private JTextArea kafkaProducerTextArea;
    private JTextArea kafkaConsumerTextArea;
    private JButton consumerButton;
    private JButton sendButton;

    private KafkaCommandProcessor kafkaCommandProcessor;


    public KafkaUtilityPanel() {
        this.kafkaCommandProcessor = new KafkaCommandProcessor();
        initializeUI();
    }

    private void initializeUI() {
        initializeComponents();
        initializeUtilityTypeRadioButtonToggle();
        initializeSendButtonListener();
        initializeConsumeMessageButtonListener();
        layoutComponents();
    }

    private void initializeComponents() {
        kafkaConsumerProducerSelection = new JLabel("Utility Type");
        kafkaProducer = new JRadioButton("Producer");
        kafkaProducer.setSelected(true);
        kafkaConsumer = new JRadioButton("Consumer");
        avroCheckbox = new JCheckBox("Avro");
        avroCheckbox.setSelected(true);

        buttonGroup = new ButtonGroup();
        buttonGroup.add(kafkaProducer);
        buttonGroup.add(kafkaConsumer);

        environmentJComboBox = new JComboBox<>(Environment.values());

        topicNameJList = new JList<>(TopicName.values());
        topicNameJList.setSelectedIndex(0);

        statusLabel = new JLabel();
        statusLabel.setFont(new Font("Serif", Font.BOLD, 11));
        statusType = new Label("Producer Status:");

        kafkaProducerTextArea = new JTextArea(50, 50);
        kafkaProducerTextArea.setBorder(BorderFactory.createTitledBorder("Producer Data Input"));
        kafkaProducerTextArea.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 10));

        kafkaConsumerTextArea = new JTextArea(50,50);
        kafkaConsumerTextArea.setBorder(BorderFactory.createTitledBorder("Consumer Data Output"));
        kafkaConsumerTextArea.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 10));
        kafkaConsumerTextArea.setBackground(Color.LIGHT_GRAY);
        kafkaConsumerTextArea.setEditable(false);

        consumerButton = new JButton("Consume Message");
        consumerButton.setVisible(false);
        sendButton = new JButton("Send Message");
    }

    private void initializeConsumeMessageButtonListener() {
        consumerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Environment environment = environmentJComboBox.getItemAt(environmentJComboBox.getSelectedIndex());
                    TopicName topicName = topicNameJList.getSelectedValue();
                    KafkaConsumerConfig kafkaConsumerConfig = new KafkaConsumerConfig();
                    String message = kafkaConsumerConfig.consume(environment, topicName, avroCheckbox.isSelected());
                    if(message == null){
                        alertWarningStatus("No message consumed from Kafka Cluster");
                    }else{
                        kafkaConsumerTextArea.setText(message);
                        alertSuccessStatus("Message consumed successfully from Kafka Cluster");
                    }
                } catch (Exception exception) {
                    logger.error("Error occurred while generating message: ", exception);
                    Throwable rootCause = exception.getCause();
                    alertFailureStatus(rootCause == null ? exception.getMessage() : rootCause.getMessage());
                }
            }
        });
    }

    private void initializeUtilityTypeRadioButtonToggle() {
        kafkaProducer.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    sendButton.setVisible(true);
                    consumerButton.setVisible(false);
                    statusType.setText("Producer Status:");
                    statusLabel.setText("");
                } catch (Exception exception) {
                    logger.error("Error occurred while hiding elements: ", exception);
                }
            }
        });
        kafkaConsumer.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    sendButton.setVisible(false);
                    consumerButton.setVisible(true);
                    statusType.setText("Consumer Status:");
                    statusLabel.setText("");
                } catch (Exception exception) {
                    logger.error("Error occurred while hiding elements: ", exception);
                }
            }
        });
    }

    private void initializeSendButtonListener() {
        sendButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    TopicName topicName = topicNameJList.getSelectedValue();
                    if (topicName == null) {
                        alertWarningStatus("Message sent without topic name!!");
                    } else {
                        sendMessage(topicName);
                    }
                } catch (Exception exception) {
                    logger.error("Error occurred while sending message: ", exception);
                    Throwable rootCause = exception.getCause();
                    alertFailureStatus(rootCause == null ? exception.getMessage() : rootCause.getMessage());
                }
            }
        });
    }

    private void layoutComponents() {
        setBorder(BorderFactory.createTitledBorder("KAFKA"));
        setLayout(new MigLayout("fillx", "[]", "[]"));

        add(kafkaConsumerProducerSelection, "split 4");
        add(kafkaProducer);
        add(kafkaConsumer);
        add(avroCheckbox, "wrap");

        add(new Label("Environment"), "split 2");
        add(environmentJComboBox, "wrap");

        add(new Label("Topic"), "aligny top, split 2");
        add(topicNameJList, "wrap");

        add(statusType, "split 2");
        add(statusLabel, "wrap");

        JScrollPane scrollPane1 = new JScrollPane(kafkaProducerTextArea);
        JScrollPane scrollPane2 = new JScrollPane(kafkaConsumerTextArea);
        scrollPane1.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPane2.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPane1.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane2.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
        add(scrollPane1, "");
        add(scrollPane2, "wrap");

        add(createButtonPanel(), "span 4");
    }

    private JPanel createButtonPanel() {
        JPanel buttonPanel = new JPanel(new MigLayout("ins 0"));
        buttonPanel.add(sendButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(430,0)));
        buttonPanel.add(consumerButton);
        return buttonPanel;
    }

    private void sendMessage(TopicName topicName) {
        Environment environment = environmentJComboBox.getItemAt(environmentJComboBox.getSelectedIndex());
        String message = kafkaProducerTextArea.getText();

        if (message.isEmpty()) {
            throw new IllegalArgumentException("Empty message");
        }
        try {
            logger.info("Entering ProduceKafkaMessage doExecute method");
            //Configure connection properties

            Properties producerConfig = createKafkaProducerProperties(environment);

            logger.info("ProduceKafkaMessage creating KafkaProducer : " + producerConfig.get("ssl.truststore.location") );
            logger.info("ProduceKafkaMessage creating KafkaProducer : " + producerConfig.get("ssl.truststore.password") );
            if (avroCheckbox.isSelected()){
                processMessageWithAvroProducer(topicName, message, producerConfig);
            }else{
                processMessageWithProducer(topicName, message, producerConfig);
            }

        } catch (Exception ex) {
            logger.info("Exception occured while running the ProduceKafkaMessage tag");
            logger.info(ex.getStackTrace().toString());
        }

        System.out.println("Send Button clicked with implementation=" + environment + ", messageType=" + topicName + ", message=" + message);
    }

    private void processMessageWithProducer(TopicName topicName, String message, Properties producerConfig) {
        //Create Kafka Producer
        try (KafkaProducer<String, String> myProducer = new KafkaProducer<>(producerConfig)) {


            logger.info("ProduceKafkaMessage created KafkaProducer");

            logger.info("ProduceKafkaMessage creating ProducerRecord");

            //Create ProducerRecord

            final ProducerRecord<String, String> myProducerRecord = new ProducerRecord<>(topicName.getCode(), message);

            logger.info("ProduceKafkaMessage created ProducerRecord");

            logger.info("ProduceKafkaMessage sending ProducerRecord");

            //Send the message
            myProducer.send(myProducerRecord, new Callback() {
                @Override
                public void onCompletion(RecordMetadata metadata, Exception exception) {
                    if(exception == null){
                        alertSuccessStatus("Message has been successfully sent to Kafka");
                    } else{
                        alertFailureStatus("Exception occurred check logs");
                        logger.info(exception.getStackTrace().toString());
                    }
                }
            });

            logger.info("ProduceKafkaMessage sent ProducerRecord");

            //Disconnect
            myProducer.close();
        }
    }

    private void processMessageWithAvroProducer(TopicName topicName, String message, Properties producerConfig) throws IOException {
        //Create Kafka Producer
        try (KafkaProducer<String, GenericRecord> myProducer = new KafkaProducer<>(producerConfig)) {


            logger.info("ProduceKafkaMessage created KafkaProducer");

            logger.info("ProduceKafkaMessage creating ProducerRecord");

            //Create ProducerRecord
            Schema schema = new Schema.Parser().parse(new File("\\\\inpnyc0011\\gldev\\Kafka\\kafka_avro_producer_utility_version1\\keys\\investorOnboarding.avsc"));
            JsonObject investorObject = (JsonObject) new JsonParser().parse(message);
            GenericRecord genericRecord = new InvestorOnboardingGenericRecordBuilder().buildInvestorOnboardingGenericRecord(schema, investorObject);

            final ProducerRecord<String, GenericRecord> myProducerRecord = new ProducerRecord<>(topicName.getCode(), genericRecord);

            logger.info("ProduceKafkaMessage created ProducerRecord");

            logger.info("ProduceKafkaMessage sending ProducerRecord");

            //Send the message
            myProducer.send(myProducerRecord, new Callback() {
                @Override
                public void onCompletion(RecordMetadata metadata, Exception exception) {
                    if(exception == null){
                        alertSuccessStatus("Message has been successfully sent to Kafka");
                    } else{
                        alertFailureStatus("Exception occurred check logs");
                        logger.info(exception.getStackTrace().toString());
                    }
                }
            });

            logger.info("ProduceKafkaMessage sent ProducerRecord");

            //Disconnect
            myProducer.close();
        }
    }

    private Properties createKafkaProducerProperties(Environment implementation) throws UnknownHostException {

        Properties producerConfig = new Properties();
        producerConfig.put("client.id", InetAddress.getLocalHost().getHostName());
        producerConfig.put("bootstrap.servers", implementation.getBootStrapServers());
        producerConfig.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        String serializer;
        if(!avroCheckbox.isSelected()){
            serializer = "org.apache.kafka.common.serialization.StringSerializer";

        }else{
            serializer = "io.confluent.kafka.serializers.KafkaAvroSerializer";
            producerConfig.put("schema.registry.url", "http://localhost:8085");
        }
        producerConfig.put("value.serializer", serializer);

        if (Environment.CLDDQA_PRODUCER == implementation) {

            String trustStoreKeyStorePassword = "ssb123!";
            producerConfig.put("security.protocol", "SSL");
            producerConfig.put("ssl.truststore.location", "\\\\inpnyc0011\\gldev\\Kafka\\kafka_producer_utility_beta\\keys\\aisdev-producer.truststore.jks");
            producerConfig.put("ssl.truststore.password", trustStoreKeyStorePassword);
            producerConfig.put("ssl.keystore.location", "\\\\inpnyc0011\\gldev\\Kafka\\kafka_producer_utility_beta\\keys\\aisdev-producer.keystore.jks");
            producerConfig.put("ssl.keystore.password", trustStoreKeyStorePassword);
            producerConfig.put("ssl.key.password", trustStoreKeyStorePassword);
            if (avroCheckbox.isSelected()) {
                producerConfig.put("schema.registry.url", "http://jabdlvc0108.it.statestr.com:8081");
            }
        }

        logger.info("Created Properties class");

        return producerConfig;
    }


    private void alertSuccessStatus(String message) {
        statusLabel.setText(message);
        statusLabel.setForeground(DARK_GREEN);
    }

    private void alertFailureStatus(String message) {
        statusLabel.setText(message + ". See console for full error trace!!!");
        statusLabel.setForeground(Color.RED);
    }

    private void alertWarningStatus(String message) {
        statusLabel.setText(message);
        statusLabel.setForeground(Color.ORANGE);
    }

}