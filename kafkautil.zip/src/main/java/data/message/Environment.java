package data.message;

public enum Environment {

    DEV("localhost:9092"),
    CLDDQA_PRODUCER("jabdlvc0105.it.statestr.com:9093,jabdlvc0106.it.statestr.com:9093,jabdlvc0107.it.statestr.com:9093"),
    CLDDQA_CONSUMER("jabdlpc0004.it.statestr.com:9093,jabdlpc0005.it.statestr.com:9093,jabdlpc0006.it.statestr.com:9093");

    private final String bootStrapServer;

    Environment(String bootStrapServer) {
        this.bootStrapServer = bootStrapServer;
    }

    public String getBootStrapServers() {
        return bootStrapServer;
    }
}
