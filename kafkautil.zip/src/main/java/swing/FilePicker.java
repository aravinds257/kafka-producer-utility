package swing;

import net.miginfocom.swing.MigLayout;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FilePicker extends JPanel {
    private JTextField textField;
    private JButton button;
    private JFileChooser fileChooser;

    public FilePicker(String text, String buttonLabel) {
        initializeUI(text, buttonLabel);
    }

    private void initializeUI(String text, String buttonLabel) {
        initializeComponents(text, buttonLabel);
        initializeButtonListeners();
        layoutComponents();
    }

    private void initializeComponents(String text, String buttonLabel) {
        fileChooser = new JFileChooser();
        textField = new JTextField(text);
        button = new JButton(buttonLabel);
    }

    private void initializeButtonListeners() {
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                if (fileChooser.showOpenDialog(FilePicker.this) == JFileChooser.APPROVE_OPTION) {
                    textField.setText(fileChooser.getSelectedFile().getAbsolutePath());
                }
            }
        });
    }

    private void layoutComponents() {
        setLayout(new MigLayout("ins 0", "[grow, fill][]"));
        add(textField);
        add(button);
    }

    public void setText(String text) {
        textField.setText(text);
    }

    public String getSelectedFilePath() {
        return textField.getText();
    }
}
