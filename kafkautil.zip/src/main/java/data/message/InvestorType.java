package data.message;

public enum InvestorType {

    ENTITY(0, "Entity"), INDIVIDUAL(1, "Individual"), JOINT(2, "Joint");

    public final int id;
    public final String description;

    private InvestorType(int id, String description) {
        this.id = id;
        this.description = description;
    }

    public static InvestorType typeOf(String description) {
        for (InvestorType investorTypeDescription : InvestorType.values()) {
            if (investorTypeDescription.getDescription().equalsIgnoreCase(description)) {
                return investorTypeDescription;
            }
        }
        throw new IllegalArgumentException("Unknown Investor Type Id: " + description);
    }

    public static InvestorType fromId(int id) {
        if (id == 0) {
            return InvestorType.ENTITY;
        } else if (id == 1) {
            return InvestorType.INDIVIDUAL;
        } else if (id == 2) {
            return InvestorType.JOINT;
        } else {
            throw new IllegalArgumentException("Unknown id for InvestorType: " + id);
        }

    }

    public int getId() {
        return id;
    }

    public String getDescription() {
        return description;
    }
}
